//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "I7000.h"
#include "I7000u.cpp"
#include "I87000.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"


TForm1 *Form1;

WORD  wRtn;
WORD  wTtlChannel;
DWORD wMaxValue;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
     // Initialize Setting for GUI
     cbModuleID->ItemIndex = 0;
     cbCom->ItemIndex      = 0;
     cbBaudRate->ItemIndex = 4;
     cbChecksum->ItemIndex = 0;

     // Setting the COM port strings
     ISetCOMString( cbCom, 1, 255 );
}
//---------------------------------------------------------------------------




void __fastcall TForm1::btnActiveClick(TObject *Sender)
{
     // Stop by User
     if ( btnActive->Caption == "Stop")
     {
          tmLoop->Enabled = false; // Stop timer
          Sleep(500);              // Wait the tmLoop to end
          Close_Com( gcPort );     // Close COM port
          btnActive->Caption = "Active";
          btnExit->Enabled   = true;
          gbConfig->Enabled  = true;
          return;
     }

     gcPort      = (char)(cbCom->ItemIndex + 1 ); // Com Port
     gdwBaudRate = StrToInt( cbBaudRate->Text );  // Baud Rate
     wRtn = IOpenCom(gcPort, gdwBaudRate);   // Open COM port
     if (wRtn != NoError)
     {
          ShowMessage( "COM port open error!!" );
          return;
     }

     gdwBuf[0] = gcPort;                           // COM Port
     gdwBuf[1] = StrToInt("0x" + eAddress->Text);  // Module Address
     gdwBuf[2] = StrToInt("0x" + cbModuleID->Text);// Module ID
     gdwBuf[3] = cbChecksum->ItemIndex;            // CheckSum Disable or Enable
     gdwBuf[4] = 100;                              // TimeOut = 0.1 second
     //gdwBuf[5] = StrToInt( "0x" + eOutVal->Text ); // 16-bit digital data to output
     gdwBuf[6] = 1;                                // string debug

     // Total Channels & Max Output value
     switch ( gdwBuf[2] )
     {
     case 0x87063:
          wTtlChannel = 4;
          wMaxValue   = 0xF;
          break;
     case 0x87054: case 0x87055: case 0x87064:
     case 0x87065: case 0x87066: case 0x87068:
          wTtlChannel = 8;
          wMaxValue   = 0xFF;
          break;
     case 0x87057:
     default:
          wTtlChannel = 16;
          wMaxValue   = 0xFFFF;
          break;
     }

     btnActive->Caption = "Stop";
     btnExit->Enabled   = false;
     gbConfig->Enabled  = false;
     tmLoop->Enabled    = true;   // Start timer

}
//---------------------------------------------------------------------------

void __fastcall TForm1::tmLoopTimer(TObject *Sender)
{
     // Change the Output value dependents on Output Mode
     gdwBuf[5] = StrToInt( "0x" + eOutVal->Text ); // 16-bit digital data to output
     switch ( rgOutputMode->ItemIndex )
     {
     case 1:   // Increment
        gdwBuf[5] = gdwBuf[5] + 1;
        if (gdwBuf[5] > wMaxValue)
            gdwBuf[5] = 0;
        break;
     case 2:   // Decrement
        gdwBuf[5] = gdwBuf[5] - 1;
        if (gdwBuf[5] < 0)
            gdwBuf[5] = wMaxValue;
        break;
     case 3:   // Shift-Left
        gdwBuf[5] = gdwBuf[5] << 1;
        if (gdwBuf[5] > wMaxValue)
            gdwBuf[5] = 1;
        break;
     case 4:   // Sift-Right
          gdwBuf[5] = gdwBuf[5] >> 1;
          if (gdwBuf[5] == 0)
             gdwBuf[5] = 1 << (wTtlChannel - 1);
        break;
     }
     eOutVal->Text  = IntToHex(gdwBuf[5], 4 );

     // Calling the Digital Output function for 87K series
     wRtn = DigitalOut_87K(gdwBuf, gfBuf, gszSend, gszReceive);
     if (wRtn != 0)
     {
         btnActiveClick( this );
         Beep();
         ShowMessage( "The Error Code:" + IntToStr(wRtn) + "\n" + IGetErrorString(wRtn) );
     }

     gdwBuf[5] = 0;
     // Calling the Digital Output Read-Back function for 87K series
     wRtn = DigitalOutReadBack_87K(gdwBuf, gfBuf, gszSend, gszReceive);
     if (wRtn != 0)
     {
          Beep();
          eInVal->Text = "Error";
     }
     else
          eInVal->Text = IntToHex( gdwBuf[5], 4 );

}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnExitClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

