//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label6;
    TLabel *Label8;
    TGroupBox *gbConfig;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label7;
    TLabel *Label5;
    TComboBox *cbModuleID;
    TComboBox *cbCom;
    TComboBox *cbBaudRate;
    TComboBox *cbChecksum;
    TEdit *eAddress;
    TEdit *eOutVal;
    TButton *btnActive;
    TButton *btnExit;
    TRadioGroup *rgOutputMode;
    TEdit *eInVal;
    TTimer *tmLoop;void __fastcall FormCreate(TObject *Sender);

    


    void __fastcall btnActiveClick(TObject *Sender);
    void __fastcall tmLoopTimer(TObject *Sender);
    void __fastcall btnExitClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
