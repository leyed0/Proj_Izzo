//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "uart.h"
#include "I87000.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Char     cPort,cData,cStop,cParity ;
DWord     w7000[80];
DWord    dwBaudRate ;
float    f7000[80];
Boolean  bComOpen, bCfgChg;
Char     szSend[80] , szReceive[80] ;
int      iCounter;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    if ( bCfgChg )
        Close_Com( cPort );
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    ComComboBox->ItemIndex = 0;
    BaudRateComboBox->ItemIndex = 4;
    bComOpen = false ;
    bCfgChg  = true ;
    cData    = 8;
    cParity  = 0;
    cStop    = 0;
    iCounter = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OpenCom()
{
    int iRet ;

    cPort = (char) (ComComboBox->ItemIndex + 1 ) ; //Get Com Port Setting
    switch ( BaudRateComboBox->ItemIndex )         //Get Baud Rate Setting
    {
        case 0 : dwBaudRate = (DWord) 115200 ;
        	 break;
        case 1 : dwBaudRate = (DWord)  57600 ;
        	 break;
        case 2 : dwBaudRate = (DWord)  38400 ;
        	 break;
        case 3 : dwBaudRate = (DWord)  19200 ;
        	 break;
        case 4 : dwBaudRate = (DWord)   9600 ;
        	 break;
        case 5 : dwBaudRate = (DWord)   4800 ;
        	 break;
        case 6 : dwBaudRate = (DWord)   2400 ;
        	 break;
        case 7 : dwBaudRate = (DWord)   1200 ;
        	 break;
        default:
                 dwBaudRate = (DWord)   9600 ;
        	 break;
    };

    iRet = Open_Com( cPort , dwBaudRate , cData , cParity , cStop );
    if ( iRet > 0 )
        if ( MessageDlg( "OPEN_COM Error Code: " + IntToStr(iRet) ,
                        mtConfirmation,
                        TMsgDlgButtons() << mbYes << mbNo, 0 ) == mrYes )
             Close();

    bComOpen = true;
    bCfgChg  = false;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ComComboBoxChange(TObject *Sender)
{
    bCfgChg = true;    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BaudRateComboBoxChange(TObject *Sender)
{
    bCfgChg = true ;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     Word wRet ;

     if ( bCfgChg && bComOpen )   // Reopen Com port
     {
        Close_Com( cPort );
        bComOpen = false;
     };

     if ( ! bComOpen )
        OpenCom();

    w7000[0] = (Word) cPort ;         // COM Port
    w7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    w7000[2] = 0x87024 ;               // Module ID

    if ( RadioButton1->Checked )
        w7000[3] = 1 ;     // CheckSum Enable
    else
        w7000[3] = 0 ;

    w7000[4] = 100;      // TimeOut = 0.1 second
    w7000[5] =   0;      // Channel No.
    w7000[6] =   1;      // string debug
    w7000[7] =   0;      //

    f7000[0] =  StrToFloat(Out->Text);
    wRet = AnalogOut_87K(w7000 , f7000, szSend , szReceive );

    if ( wRet != 0 )
    {
        //Application->MessageBox( (char) "The Error Code:" + IntToStr(wRet),
        //                         (char) "AnalogIn() error !!! " , MB_OK );
        ShowMessage( "AnalogIn() Error!!\nThe Error Code:" + IntToStr(wRet) );
        Close_Com (cPort);
    };

    iCounter++ ;
    TVarRec args[3] = {6,3, f7000[0] };
    Label1->Caption = "Counter=" + IntToStr(iCounter)
                      + "\nThe Analog Output value:" + Format("%*.*f", args, 2) ;
}
//---------------------------------------------------------------------------




