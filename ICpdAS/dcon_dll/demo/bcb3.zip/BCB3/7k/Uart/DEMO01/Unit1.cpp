//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "uart.h"
#include "I7000.h"

//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
short nA,nB,nC;

nA= (short) StrToInt(Edit1->Text);
nB= (short) StrToInt(Edit2->Text);
nC=Short_Sub_2(nA,nB);
Edit1->Text=IntToStr(nA);
Edit2->Text=IntToStr(nB);
Edit3->Text=IntToStr(nC);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
float fA,fB,fC;

fA=StrToFloat(Edit4->Text);
fB=StrToFloat(Edit5->Text);
fC=Float_Sub_2(fA,fB);
Edit4->Text=FloatToStr(fA);
Edit5->Text=FloatToStr(fB);
Edit6->Text=FloatToStr(fC);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
WORD w7000[10];
float f7000[10];
char szSend[80],szReceive[80];

strcpy(szSend,"");
strcpy(szReceive,"");

w7000[0]=(WORD)StrToInt(Edit7->Text);
w7000[1]=(WORD)StrToInt(Edit8->Text);
w7000[2]=(WORD)StrToInt(Edit9->Text);
w7000[3]=(WORD)StrToInt(Edit10->Text);

f7000[0]=StrToFloat(Edit11->Text);
f7000[1]=StrToFloat(Edit12->Text);
f7000[2]=StrToFloat(Edit13->Text);
f7000[3]=StrToFloat(Edit14->Text);

Test(w7000,f7000,szSend,szReceive);

Edit7->Text=IntToStr(w7000[0]);
Edit8->Text=IntToStr(w7000[1]);
Edit9->Text=IntToStr(w7000[2]);
Edit10->Text=IntToStr(w7000[3]);

Edit11->Text=FloatToStr(f7000[0]);
Edit12->Text=FloatToStr(f7000[1]);
Edit13->Text=FloatToStr(f7000[2]);
Edit14->Text=FloatToStr(f7000[3]);

Edit15->Text=szSend;
Edit16->Text=szReceive;
}
//---------------------------------------------------------------------------
