//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "uart.h"
#include "i7000.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

//Char     cPort,cData,cStop,cParity ;
Word     w7000[80];
DWord    dwBaudRate ;
float    f7000[80];
//Boolean  bComOpen, bCfgChg;
Char     szSend[80] , szReceive[80] ;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
    Integer A, B , C;

    A = StrToInt(Edit1->Text);
    B = StrToInt(Edit2->Text);
    C = StrToInt(Edit3->Text);

    w7000[0] = (Word) A ;
    w7000[1] = (Word) B ;
    w7000[2] = (Word) C ;
    Test(w7000 , f7000 , szSend , szReceive);

    Edit1->Text = IntToStr(w7000[0]);
    Edit2->Text = IntToStr(w7000[1]);
    Edit3->Text = IntToStr(w7000[2]);
    Send->Text  = szSend;
    Receive->Text = szReceive;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    Edit4->Text = IntToHex(Get_Dll_Version(),4);    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
    Close()
    ;
}
//---------------------------------------------------------------------------

