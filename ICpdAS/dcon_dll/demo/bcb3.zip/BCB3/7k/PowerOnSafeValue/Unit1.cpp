//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "uart.h"
#include "i7000.h"
#include "I7000u.cpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Boolean  bComOpen;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    Close_Com( gcPort );
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    TypeComboBox->ItemIndex = 0;
    ComComboBox->ItemIndex = 0;
    BaudRateComboBox->ItemIndex = 4;
    bComOpen = false ;
    strcpy(gszSend, "             ");
    strcpy(gszReceive, "              ");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OpenCom()
{
    int iRet ;

    gcPort = (char) (ComComboBox->ItemIndex + 1 ) ; //Get Com Port Setting
    gdwBaudRate = StrToInt(BaudRateComboBox->Text);
    iRet = IOpenCom( gcPort , gdwBaudRate );
    if ( iRet > 0 )
        if ( MessageDlg( "OPEN_COM Error Code: " + IntToStr(iRet)
                         + "\n" + IGetErrorString( (WORD) iRet ) ,
                         mtConfirmation,
                         TMsgDlgButtons() << mbYes << mbNo, 0 ) == mrYes )
             Close();
        else
            ;
    else
        bComOpen = true;
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Button3Click(TObject *Sender)
{
     Word wRet ;

     if ( bComOpen )   // Reopen Com port
     {
        Close_Com( gcPort );
        bComOpen = false;
     };

     if ( ! bComOpen )
        OpenCom();
     if ( ! bComOpen ) return ;

    //------- firstly, set the PowerOn Value -----------
    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    gw7000[2] = (WORD) StrToInt( "0x" + TypeComboBox->Text);

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[5] = (WORD) StrToInt(ePowerOn->Text);   //PowerOn Value   range 00~03
    gw7000[6] = 1;                                 // string debug
    gw7000[7] = (WORD) StrToInt(eSafe->Text);      //Safe Value   range 00~03

    Beep();
    wRet = SetPowerOnSafeValue(gw7000 , gf7000, gszSend , gszReceive );
    if ( wRet != 0 )
    {
        if ( wRet == 4 )
            ShowMessage( "SetPowerOnSafeValue() Error!!\nThe Error Code:" + IntToStr(wRet) + "\nPlease Don't Exceed 3 !"
                         + "\n" + IGetErrorString( wRet ) );
        else
            ShowMessage( "SetPowerOnSafeValue() Error!!\nThe Error Code:" + IntToStr(wRet)
                         + "\n" + IGetErrorString( wRet ) );
    };
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     Word wRet ;

     if ( bComOpen )   // Reopen Com port
     {
        Close_Com( gcPort );
        bComOpen = false;
     };

     if ( ! bComOpen )
        OpenCom();
     if ( ! bComOpen ) return ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    //gw7000[2] = (WORD) StrToInt("0x" + TypeComboBox->Text);   // Not Used

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[5] = 1;                                 // Enable Host Watchdog
    gw7000[6] = 1;                                 // string debug
    gw7000[7] = (WORD) StrToInt(eTimeInterval->Text); //Time Interval

    Beep();
    wRet = ToSetupHostWatchdog(gw7000 , gf7000, gszSend , gszReceive );
    if ( wRet != 0 )
    {
        ShowMessage( "ToSetupHostWatchdog() Error!!\nThe Error Code:" + IntToStr(wRet)
                     + "\n" + IGetErrorString( wRet ) );
    };

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
     Word wRet ;

     if ( bComOpen )   // Reopen Com port
     {
        Close_Com( gcPort );
        bComOpen = false;
     };

     if ( ! bComOpen )
        OpenCom();
     if ( ! bComOpen ) return ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    Beep();
    wRet = HostIsOK(gw7000 , gf7000, gszSend , gszReceive );
    if ( wRet != 0 )
    {
        ShowMessage( "HostIsOK() Error!!\nThe Error Code:" + IntToStr(wRet)
                     + "\n" + IGetErrorString( wRet ) );
    };
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
     Word wRet ;

     if ( bComOpen )   // Reopen Com port
     {
        Close_Com( gcPort );
        bComOpen = false;
     };

     if ( ! bComOpen )
        OpenCom();
     if ( ! bComOpen ) return ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    Beep();
    wRet = ResetModuleHostWatchdogStatus(gw7000 , gf7000, gszSend , gszReceive );
    if ( wRet != 0 )
    {
        ShowMessage( "ResetModuleHostWatchdogStatus() Error!!\nThe Error Code:" + IntToStr(wRet)
                     + "\n" + IGetErrorString( wRet ) );
    };
}
//---------------------------------------------------------------------------

