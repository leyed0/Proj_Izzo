//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "I7000.h"
#include "uart.h"
#include "I7000u.cpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Boolean  bComOpen;
Boolean  bProcessing;
long     wErrCnt;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    //if(Get_Com_Status(gcPort))
    Close_Com( gcPort );
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    ComComboBox->ItemIndex = 0;
    BaudRateComboBox->ItemIndex = 4;
    bComOpen               = false ;
    bProcessing            = False;
    Timer1->Interval       = 2000;
    Timer1->Enabled        = False;
    strcpy(gszSend, "             ");
    strcpy(gszReceive, "              ");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OpenCom()
{
    int iRet ;

    gcPort = (char) (ComComboBox->ItemIndex + 1 ) ; //Get Com Port Setting
    gdwBaudRate = StrToInt(BaudRateComboBox->Text);
    iRet = IOpenCom( gcPort , gdwBaudRate );
    if ( iRet > 0 )
        if ( MessageDlg( "OPEN_COM Error Code: " + IntToStr(iRet)
                         + "\n" + IGetErrorString( (WORD) iRet ) ,
                         mtConfirmation,
                         TMsgDlgButtons() << mbYes << mbNo, 0 ) == mrYes )
             Close();
        else
            ;
    else
        bComOpen = true;
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Button3Click(TObject *Sender)
{
     Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ReadModuleHostWatchdogStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ReadModuleHostWatchdogStatus() Error!!", wRet );

    Edit1->Text = IntToStr(gw7000[5]);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     Word wRet ;

    gw7000[0] = (Word) gcPort ;                                 // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text );        // Module Address
    //gw7000[2] = (WORD) StrToInt("0x" + TypeComboBox->Text);   // Not Used

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;                               // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                                  // TimeOut = 0.1 second
    if ((eTimeInterval->Text == "") || (eTimeInterval->Text == "0"))
        gw7000[5] = 0;                                // Disable Host Watchdog
    else
        gw7000[5] = 1;                                // Enable Host Watchdog
    gw7000[6] = 1;                                    // string debug
    gw7000[7] = (WORD) StrToInt(eTimeInterval->Text); //Time Interval

    Beep();
    wRet = ToSetupHostWatchdog(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ToSetupHostWatchdog() Error!!", wRet );

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
    //Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    //wRet =
    HostIsOK(gw7000 , gf7000, gszSend , gszReceive );
    //Check_Error( "HostIsOK() Error!!", wRet );
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
     Word wRet ;

    Timer1->Enabled = False;
    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ResetModuleHostWatchdogStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ResetModuleHostWatchdogStatus() Error!!", wRet );

    ShowMessage((AnsiString)("Host Watchdog has been disabled when the Host Watchdog status = 4.\n")
         + "You must setup the Host Watchdog again after you clear the status to 0.\n\n"
         + "Press button [OK] to setup the Host Watchdog" );

     Button1Click( Sender );
     Timer1->Enabled = True;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)
{
     Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ToReadHostWatchdog(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ToReadHostWatchdog() Error!!", wRet );

    Edit2->Text = IntToStr(gw7000[5]);
    Edit3->Text = IntToStr(gw7000[7]);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
     Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text );    // Module Address
    gw7000[2] = (Word) StrToInt( "0x" + eModuleID->Text );  // Module ID

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ReadModuleResetStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ReadModuleResetStatus() Error!!", wRet );

    Edit4->Text = IntToStr(gw7000[5]);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
     if ( ! bComOpen )
        return ;

     if ( bProcessing == True )
        return ;
     else
         bProcessing = True ;

     Beep();

     Button3Click(Sender);
     if (Edit1->Text == "4")
        ShowMessage((AnsiString)("Host Watchdog Status = 4\n\n")
               + "Host is down, and this moudle go to safe state.\n"
               + "All output command will be ignored when module in safe state.\n\n"
               + "The safe value is used to prevent your applications from critical damages.\n"
               + "To continue your job correctly,\n"
               + "you must clear this status firstly and then output the correct value again.");

     Button6Click(Sender);

     Button7Click(Sender);
     if ( Edit4->Text == "1" )
         ShowMessage( (AnsiString)("Module Status S = 1\n\n")
            + "This moudle has been reset and use the PowerOn value!!\n"
            + "The PowerOn value may be not appropriate and may be dangerous for your jobs.\n"
            + "Thus, you must output the correct value again for your work correctly." );

     bProcessing = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Check_Error(AnsiString sFunctionName, int wErrCode)
{
    if ( wErrCode == NoError ) {
        wErrCnt = 0;
        return ;
    }

    if ((wErrCode == 15) || (wErrCode == 10)) {
        wErrCnt ++ ;
        if (wErrCnt > 10)
            return;
        if (wErrCnt > 9) {
            Beep();
            ShowMessage( sFunctionName + "\n\nModule has no response for "
                 + IntToStr(wErrCnt) + " times continuity."
                 + "\n\nThe connection between module and computer may be broken."
                 + "\nOr, this module has been break down.\nPlease check it!!" );
        }
    }
    else
    {
        Beep();
        ShowMessage( sFunctionName + "\n\nThe Error Code:" + IntToStr(wErrCode) + "\n"
                     + IGetErrorString((Word)wErrCode) );
    }
}

void __fastcall TForm1::btnActiveClick(TObject *Sender)
{
    if  (btnActive->Caption == "Stop")  {
        btnActive->Caption = "Active";
        Timer1->Enabled    = False;
        //Close_Com (gcPort);
        GroupBox1->Enabled = True;
        Button1->Enabled   = False;
        Button3->Enabled   = False;
        Button4->Enabled   = False;
        Button5->Enabled   = False;
        Button6->Enabled   = False;
        Button7->Enabled   = False;

        Button2->Enabled   = True;
        return;
    };

    btnActive->Caption    = "Stop";
    GroupBox1->Enabled     = False;
    OpenCom();
    if (bComOpen == False)   //COM port open failure
    {
        btnActiveClick( Sender );
        return;
    }

    Button1->Enabled = True;
    Button3->Enabled = True;
    Button4->Enabled = True;
    Button5->Enabled = True;
    Button6->Enabled = True;
    Button7->Enabled = True;

    Button2->Enabled = False;
    wErrCnt          = 0;
    Button7Click(Sender);   //Read Module-Reset-Status ==> Clear status
    Timer1->Enabled  = True;

}
//---------------------------------------------------------------------------

