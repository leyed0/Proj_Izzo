//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "uart.h"
#include "i7000.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Char     cPort,cData,cStop,cParity ;
Word     w7000[80];
DWord    dwBaudRate ;
float    f7000[80];
Boolean  bComOpen, bCfgChg;
Char     szSend[80] , szReceive[80] ;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
    cData   = 8;   //8 Data bits
    cStop   = 0;   //0: One Stop bit
    cParity = 0;   //Non Parity Check
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
    Word wRetVal ;

    cPort       = (char) StrToInt( Port->Text );
    dwBaudRate  = (DWord) StrToInt(BaudRate->Text);
    wRetVal     = Open_Com(cPort,dwBaudRate,cData,cParity,cStop); // N 8 1
    Edit3->Text = IntToStr(wRetVal); //the return value of the open_com 0==>OK,others ==>error
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    Word wRetVal;
    Word wAddr,wModule;

    wAddr         = (Word) StrToInt(Address->Text);
    wModule       = (Word) StrToInt(Module->Text);
    w7000[0]      = (Word) cPort;
    w7000[1]      = wAddr;
    w7000[2]      = wModule;
    //w7000[3]    = 0;      // CheckSum disable
    w7000[3]      = (Word) StrToInt( CheckSum->Text ); //Get Checksum status
    w7000[4]      = 200;     // TimeOut Constant
    w7000[6]      = 1;       // debug mode
    wRetVal       = AnalogIn(w7000,f7000,szSend,szReceive);
    Edit7->Text   = IntToStr(wRetVal);       //the return value of AnalogIn,0==>OK ,others==>error
    Send->Text    = szSend;
    Receive->Text = szReceive;
}
//---------------------------------------------------------------------------

