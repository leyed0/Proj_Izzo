//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "i7000.h"
#include "i7000u.cpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Char     cPort,cData,cStop,cParity ;
Word     w7000[80];
DWord    dwBaudRate;
float    f7000[80];
Boolean  bComOpen, bCfgChg;
Boolean  bProcessing;
long     iLoopCnt;
long     iTCnt1, iTCnt2;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    if ( bCfgChg )
        Close_Com( cPort );
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    ComComboBox->ItemIndex = 0;
    bComOpen               = false ;
    bCfgChg                = true ;
    cData                  = 8;
    cParity                = 0 ;
    cStop                  = 0;
    Timer1->Enabled        = False;
    Timer1->Interval       = 200;
    iLoopCnt               = 0;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::OpenCom()
{
    int iRet ;

    cPort = (char) (ComComboBox->ItemIndex + 1 ) ; //Get Com Port Setting
    dwBaudRate = (DWord) 9600 ;

    iRet = Open_Com( cPort , dwBaudRate , cData , cParity , cStop );
    if ( iRet > 0 )
        if ( MessageDlg( "OPEN_COM Error Code: " + IntToStr(iRet) ,
                        mtConfirmation,
                        TMsgDlgButtons() << mbYes << mbNo, 0 ) == mrYes )
             Close();
        else
            ;
    else
        bComOpen = true;
}
//---------------------------------------------------------------------------




void __fastcall TForm1::Button1Click(TObject *Sender)
{
     if (Button1->Caption == "Stop") {
         Timer1->Enabled  = False;
         Button1->Caption = "Active";
         Button2->Enabled = True;
         return;
     }

     Button1->Caption = "Stop";
     Button2->Enabled = false;
     iTCnt1 = 0; iTCnt2 = 0;
     iLoopCnt = 0;
     lTtlLoops->Caption = "0";
     lErrCnts->Caption = "0";
     lbCmd->Items->Clear();
     lbErr->Items->Clear();

     if (bComOpen) {  // Reopen Com port
        Close_Com(cPort);
        bComOpen = false;
     }

     OpenCom();

     if (bComOpen)
          Timer1->Enabled = True;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
     int iStart, iEnd, i, iRtn;

     if (bProcessing == true)           //avoid to reenter this function
        return ;
     else
        bProcessing = true;

     Application->ProcessMessages();
     iLoopCnt++;
     lTtlLoops->Caption = IntToStr( iLoopCnt );
     lbCmdAdd("");
     lbCmdAdd("=========== Loop:" + IntToStr(iLoopCnt));
     //lbErrAdd("");
     //lbErrAdd("=========== Loop:" + IntToStr(iLoopCnt));
     //gszSend = "#**" + #13 ;
     strcpy(gszSend,"#**") ;                    //Send the synchronise command
     iRtn = Send_Cmd(cPort, gszSend, 0);
     if (iRtn != NoError)
        lbErrAdd2("Send Cmd:#**   ==> ErrorCode:" + IntToStr(iRtn) );
     else
        lbCmdAdd("Send Cmd:#** " );

     Sleep(200);                           //Sleep 200 mSeconds( 0.2 seconds )
     iStart = StrToInt("0x" + StartAddr->Text);
     iEnd   = StrToInt("0x" + EndAddr->Text);
     for (i=iStart; i<=iEnd; i++ ) {
         Read7012( i );
         Application->ProcessMessages();
         if (Button1->Caption == "Active") {
            bProcessing = false;
            return ;
         }
     }

     bProcessing = false;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Read7012(int i)
{
     String sAddr;
     WORD   wT;
     int    iRtn ;

     Application->ProcessMessages();
     sAddr = IntToHex(i,2);
     strcpy(gszSend,((AnsiString)("$" + sAddr + "4")).c_str() ) ;             //Read the synchronise value

     //Clear the buffer for debug
     strcpy(gszReceive,"");

     iRtn = Send_Receive_Cmd(cPort, gszSend, gszReceive, (WORD)200,(WORD) 0,  &wT);
     if (iRtn == NoError)
         if (gszReceive[3] != '1')
             //lbErrAdd2( '$' + sAddr + '4  ==> ' + String(gszReceive) + '  ==>S<>1:NotFirstReading')
             // ********** Module Address ******* Receive String by hex ********* Loop Counters **********
             lbErrAdd2( "$" + sAddr + "4  ==> " + GetNS(gszReceive) + "  ==>LoopCnt:" + lTtlLoops->Caption );
         else
            lbCmdAdd( "$" + sAddr + "4  ==> " + String(gszReceive) );
     else
        //lbErrAdd2( '$' + sAddr + '4  ==> ' + String(gszReceive) + '  ==> ErrCode:' + IntToStr(iRtn) );
        // ********** Module Address ***** Receive String by hex ************ Error Code ************* Loop Counters *******
        lbErrAdd2( "$" + sAddr + "4  ==> " + GetNS(gszReceive) + " =>ErrCd:" + IntToStr(iRtn) + " =>LpCnt:" + lTtlLoops->Caption );
}

//---------------------------------------------------------------------------
void __fastcall TForm1::lbCmdAdd(AnsiString s)
{
     iTCnt1++;
     if (iTCnt1 > 400) {
        iTCnt1 = 1;
        lbCmd->Items->Clear();
     }

     lbCmd->Items->Add( s );
}

//---------------------------------------------------------------------------
void __fastcall TForm1::lbErrAdd(AnsiString s)
{
     iTCnt2++;
     if (iTCnt2 > 400) {
        iTCnt2 = 1;
        lbErr->Items->Clear();
     }

     lbErr->Items->Add( s );
}

//---------------------------------------------------------------------------
void __fastcall TForm1::lbErrAdd2(AnsiString s)
{
     lErrCnts->Caption = IntToStr(StrToInt(lErrCnts->Caption) + 1);
     lbErrAdd( s );
}

//---------------------------------------------------------------------------
AnsiString __fastcall TForm1::GetNS(char *NS)
{
   int i;
   AnsiString AStr;
   Char AChar;

   AStr = "";
   for (i=0;i<=12;i++) {
        AChar = NS[i];
        AStr = AStr + IntToHex((int)AChar,2);
   }
   return AStr ;
}

