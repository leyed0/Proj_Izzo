//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label2;
    TLabel *Label4;
    TLabel *Label1;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *lTtlLoops;
    TLabel *Label6;
    TLabel *lErrCnts;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TEdit *StartAddr;
    TButton *Button1;
    TButton *Button2;
    TComboBox *ComComboBox;
    TEdit *EndAddr;
    TListBox *lbCmd;
    TListBox *lbErr;
    TTimer *Timer1;
    void __fastcall Button2Click(TObject *Sender);
    
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall OpenCom();
    
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
    void       __fastcall Read7012(int i);
    void       __fastcall lbCmdAdd(AnsiString s);
    void       __fastcall lbErrAdd(AnsiString s);
    void       __fastcall lbErrAdd2(AnsiString s);
    AnsiString __fastcall GetNS(char *NS);
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
