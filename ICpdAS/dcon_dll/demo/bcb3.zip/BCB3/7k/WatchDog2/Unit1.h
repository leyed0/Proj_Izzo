//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TImage *Image2;
    TShape *Shape1;
    TImage *PicHostWatchdog;
    TImage *PicModuleWatchdog;
    TShape *sBreakModule;
    TShape *sBreakHostPC;
    TGroupBox *GroupBox1;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label2;
    TRadioGroup *RadioGroup1;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TComboBox *ComComboBox;
    TComboBox *BaudRateComboBox;
    TEdit *Address;
    TButton *Button2;
    TButton *btnActive;
    TTimer *Timer1;
    TShape *Shape5;
    TShape *sBreakLine;
    TButton *Button1;
    TTimer *TimerSendHostIsOK;
    TTimer *TimerModuleReset;
    TTimer *TimerHostPCDead;
    TLabel *Label1;
    TEdit *eModuleID;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall OpenCom();

    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall btnActiveClick(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall TimerSendHostIsOKTimer(TObject *Sender);
    void __fastcall TimerModuleResetTimer(TObject *Sender);
    void __fastcall TimerHostPCDeadTimer(TObject *Sender);
    void __fastcall sBreakHostPCMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall Image1Click(TObject *Sender);
    void __fastcall PicModuleWatchdogClick(TObject *Sender);
    
    void __fastcall sBreakModuleMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall Image2Click(TObject *Sender);
private:	// User declarations
    void __fastcall Check_Error(AnsiString sFunctionName, int wErrCode);
    void __fastcall FSendHostIsOK();
    void __fastcall FSetupHostWatchdog();
    void __fastcall FStopHostWatchdog();
    void __fastcall FClearHostFailureMode();
    int  __fastcall FReadHostWatchdogStatus();
    int  __fastcall FReadModuleResetStatus();
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
