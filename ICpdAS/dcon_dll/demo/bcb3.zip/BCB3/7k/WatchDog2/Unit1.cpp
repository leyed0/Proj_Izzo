//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "I7000.h"
#include "I7000u.cpp"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

//void __fastcall OpenCom();
TForm1 *Form1;

Boolean  bCOMOpen;
Boolean  bProcessing;
long     wErrCnt;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    ComComboBox->ItemIndex = 0;
    BaudRateComboBox->ItemIndex = 4;
    bCOMOpen               = false ;
    bProcessing            = False;
    Timer1->Interval       = 2000;
    Timer1->Enabled        = False;
    Image1->Picture->LoadFromFile("Term.bmp");
    Image2->Picture->LoadFromFile("I7012D.bmp");
    PicHostWatchdog->Picture->LoadFromFile("HWDog.bmp");
    PicModuleWatchdog->Picture->LoadFromFile("MWDog.bmp");
    strcpy(gszSend, "             ");
    strcpy(gszReceive, "              ");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::OpenCom()
{
    int iRet ;

    gcPort = (char) (ComComboBox->ItemIndex + 1 ) ; //Get Com Port Setting
    gdwBaudRate = StrToInt(BaudRateComboBox->Text);
    iRet = IOpenCom( gcPort , gdwBaudRate );
    if ( iRet > 0 )
        if ( MessageDlg( "OPEN_COM Error Code: " + IntToStr(iRet)
                         + "\n" + IGetErrorString( (WORD) iRet ) ,
                         mtConfirmation,
                         TMsgDlgButtons() << mbYes << mbNo, 0 ) == mrYes )
             Close();
        else
            ;
    else
        bCOMOpen = true;
}
//---------------------------------------------------------------------------



int __fastcall TForm1::FReadHostWatchdogStatus()
{
    Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ReadModuleHostWatchdogStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ReadModuleHostWatchdogStatus() Error!!", wRet );

    return gw7000[5];
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FSetupHostWatchdog()
{
    Word wRet ;

    gw7000[0] = (Word) gcPort ;                                 // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text );        // Module Address
    //gw7000[2] = (WORD) StrToInt("0x" + TypeComboBox->Text);   // Not Used
    //gw7000[2] = 0x7021;

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;                               // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 200;                                  // TimeOut = 0.1 second
    gw7000[5] = 1;                                    // Enable Host Watchdog
    gw7000[6] = 1;                                    // string debug
    gw7000[7] = 50;                                   //Time Interval 5 Second

    wRet = ToSetupHostWatchdog(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( AnsiString("ToSetupHostWatchdog() Error!!\n") + "SendTo7000:" + AnsiString(gszSend) + "\nReceiveFrom7000:" + AnsiString(gszReceive) , wRet );

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FStopHostWatchdog()
{
     Word wRet ;

    gw7000[0] = (Word) gcPort ;                                 // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text );        // Module Address
    //gw7000[2] = (WORD) StrToInt("0x" + TypeComboBox->Text);   // Not Used

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;                               // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 200;                                  // TimeOut = 0.1 second
    gw7000[5] = 0;                                    // Disable Host Watchdog
    gw7000[6] = 1;                                    // string debug
    gw7000[7] = 0;                                    //Time Interval 5 Second

    wRet = ToSetupHostWatchdog(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ToSetupHostWatchdog() Error!!", wRet );

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FSendHostIsOK()
{
    //Word wRet ;

    if ( ! bCOMOpen ) return ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    HostIsOK(gw7000 , gf7000, gszSend , gszReceive );
    //Check_Error( "HostIsOK() Error!!", wRet );
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FClearHostFailureMode()
{
    Word wRet ;

    Timer1->Enabled = False;
    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text ); // Module Address
    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ResetModuleHostWatchdogStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ResetModuleHostWatchdogStatus() Error!!", wRet );

    Timer1->Enabled = True;
}
//---------------------------------------------------------------------------


int __fastcall TForm1::FReadModuleResetStatus()
{
    Word wRet ;

    gw7000[0] = (Word) gcPort ;         // COM Port
    gw7000[1] = (Word) StrToInt( "0x" + Address->Text );  // Module Address
    gw7000[2] = (Word) StrToInt( "0x" + eModuleID->Text); // Module ID

    if ( RadioButton1->Checked )
        gw7000[3] = 1 ;     // CheckSum Enable
    else
        gw7000[3] = 0 ;

    gw7000[4] = 100;                               // TimeOut = 0.1 second
    gw7000[6] = 1;                                 // string debug

    wRet = ReadModuleResetStatus(gw7000 , gf7000, gszSend , gszReceive );
    Check_Error( "ReadModuleResetStatus() Error!!", wRet );

    return gw7000[5];
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
     if ( ! bCOMOpen )
        return ;
     if ( sBreakHostPC->Visible ) return;

     if ( bProcessing == True )
          return ;
     else
          bProcessing = True ;

     if ( FReadHostWatchdogStatus() == 4 )
          TimerHostPCDead->Enabled = True;

     if ( FReadModuleResetStatus() == 1 )
          TimerModuleReset->Enabled = True;

     bProcessing = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Check_Error(AnsiString sFunctionName, int wErrCode)
{
    if ( wErrCode == NoError ) {
        wErrCnt = 0;
        sBreakLine->Visible   = False;
        sBreakModule->Visible = False;
        return ;
    }

    if ((wErrCode == 15) || (wErrCode == 10)) {
        if ( wErrCnt < 100 ) wErrCnt ++ ;
        if (wErrCnt > 0) {
             sBreakLine->Visible   = True;
             sBreakModule->Visible = True;
        }
    }
    else
    {
        Beep();
        ShowMessage( sFunctionName + "\n\nThe Error Code:" + IntToStr(wErrCode) + "\n"
                     + IGetErrorString((Word)wErrCode) );
    }
}

void __fastcall TForm1::btnActiveClick(TObject *Sender)
{
    if  (btnActive->Caption == "Stop")  {
        btnActive->Caption = "Active";
        if ( Button1->Tag == 1 )
           Button1Click( Sender );
        TimerHostPCDead->Enabled  = False;
        TimerModuleReset->Enabled = False;
        Timer1->Enabled    = False;
        Close_Com (gcPort);
        GroupBox1->Enabled = True;
        return;
    };

    btnActive->Caption    = "Stop";
    GroupBox1->Enabled     = False;
    OpenCom();
    if (bCOMOpen == False)   //COM port open failure
    {
        btnActiveClick( Sender );
        return;
    }

    wErrCnt = 0;
    FReadModuleResetStatus();
    Timer1->Enabled  = True;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    if(Get_Com_Status(gcPort))
        Close_Com( gcPort );
    Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     if ( ! bCOMOpen ) return;
     if ( Button1->Tag == 0 )     //Enable the Host Watchdog
     {
          Button1->Caption = "Disable Host Watchdog";
          Button1->Tag     = 1;
          FSetupHostWatchdog();
     }
     else
     {
          Button1->Caption = "Enable Host Watchdog";
          Button1->Tag     = 0;
          FClearHostFailureMode();
          FStopHostWatchdog();
          TimerHostPCDead->Enabled = False;
     };
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TimerSendHostIsOKTimer(TObject *Sender)
{
     if ( ! bCOMOpen ) return;
     if ( sBreakHostPC->Visible ) return;
     if ( bProcessing )
        return;
     else
        bProcessing = True;
     FSendHostIsOK();
     bProcessing = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TimerModuleResetTimer(TObject *Sender)
{
     int i, st, lp;

     if ( ! bCOMOpen ) return ;
     if ( bProcessing )
        return;
     else
        bProcessing = True;

     Beep();
     sBreakModule->Visible = True;
     st = 10;  //Step interval
     lp = 6;   //total loops
     PicModuleWatchdog->Visible = True;
     for (i=1;i<=lp;i++)
     {
         PicModuleWatchdog->Top    = PicModuleWatchdog->Top - st;
         PicModuleWatchdog->Height = PicModuleWatchdog->Height + st;
         PicModuleWatchdog->Width  = PicModuleWatchdog->Width + st ;
         Application->ProcessMessages();
         Sleep( 100 );
     }

     PicModuleWatchdog->Visible = False;
     PicModuleWatchdog->Top     = PicModuleWatchdog->Top    + st * lp;
     PicModuleWatchdog->Width   = PicModuleWatchdog->Width  - st * lp;
     PicModuleWatchdog->Height  = PicModuleWatchdog->Height - st * lp;
     sBreakModule->Visible      = False;
     bProcessing = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TimerHostPCDeadTimer(TObject *Sender)
{
     int i, st, lp;

     if ( ! bCOMOpen ) return ;
     if ( bProcessing )
        return;
     else
        bProcessing = True;

     Beep();
     st = 10;  //Step interval
     lp = 6;   //total loops
     sBreakLine->Visible      = True;
     sBreakHostPC->Visible    = True;
     PicHostWatchdog->Visible = True;
     for (i=1;i<=lp;i++)
     {
         PicHostWatchdog->Top    = PicHostWatchdog->Top    - st;
         PicHostWatchdog->Left   = PicHostWatchdog->Left   - st;
         PicHostWatchdog->Height = PicHostWatchdog->Height + st;
         PicHostWatchdog->Width  = PicHostWatchdog->Width  + st;
         Application->ProcessMessages();
         Sleep( 100 );
     }

     PicHostWatchdog->Visible = False;
     PicHostWatchdog->Top     = PicHostWatchdog->Top    + st * lp;
     PicHostWatchdog->Left    = PicHostWatchdog->Left   + st * lp;
     PicHostWatchdog->Width   = PicHostWatchdog->Width  - st * lp;
     PicHostWatchdog->Height  = PicHostWatchdog->Height - st * lp;
     sBreakLine->Visible      = False;
     sBreakHostPC->Visible    = False;
     bProcessing = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::sBreakHostPCMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     if ( ! bCOMOpen )  return;
     TimerSendHostIsOK->Enabled = ! TimerSendHostIsOK->Enabled;
     sBreakHostPC->Visible      = ! TimerSendHostIsOK->Enabled;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image1Click(TObject *Sender)
{
     if ( ! bCOMOpen )  return;
     TimerSendHostIsOK->Enabled = ! TimerSendHostIsOK->Enabled;
     sBreakHostPC->Visible      = ! TimerSendHostIsOK->Enabled;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PicModuleWatchdogClick(TObject *Sender)
{
     TimerModuleReset->Enabled = False;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::sBreakModuleMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
     TimerModuleReset->Enabled = False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image2Click(TObject *Sender)
{
     TimerModuleReset->Enabled = False;
}
//---------------------------------------------------------------------------

