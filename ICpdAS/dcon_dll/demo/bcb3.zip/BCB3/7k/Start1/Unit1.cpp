//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "I7000.h"
#include "uart.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Button1Click(TObject *Sender)
{
    Word wt;
    char Port;
    char Send[80], Receive[80];

    Port = (char)(1);
    Open_Com(Port, 9600, (char)(8), (char)(0), (char)(0));
    strcpy(Send,"$01M");
    strcpy(Receive,"                      ");
    Send_Receive_Cmd( Port, Send, Receive, 100, 0, &wt);
    Button1->Caption = AnsiString(Receive);
    Close_Com( Port );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
    char Port;
    char Send[80], Receive[80];
    Word w7000[10];
    float f7000[10];

    Port      = (char) 2;             //Use COM2
    Open_Com( Port, 9600, (char)8, (char)0, (char)0 );   //Open COM Port with Baud Rate 9600, 8 DataBits, None Paritybits , One stop bit
    strcpy(Send,"      ");            //Declare the buffer
    strcpy(Receive,"   ");            //Declare the buffer
    w7000[0]  = (WORD)Port;           //COM port that you using
    w7000[1]  = (WORD)1;              //Module Address at 0x01
    w7000[2]  = (WORD)0x7013;         //Module ID 0x7013
    w7000[3]  = (WORD)0;              //Checksum 0:disable
    w7000[4]  = (WORD)100;            //Timeout value 0.1 second

    //Call the function "AnalogIn" to get the value from module
    //Parameters are w7000(0), f7000(0), SendTo7000, ReceiveFrom7000
    AnalogIn (w7000, f7000, Send, Receive);

    //Use caption of button "Command2" to show the analog value
    Button2->Caption = FloatToStr(f7000[0]);
    //Close the COM port that you opened previously
    Close_Com( Port );
}
//---------------------------------------------------------------------------
