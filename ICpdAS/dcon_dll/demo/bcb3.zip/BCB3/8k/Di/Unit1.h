//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *gbConfig;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label7;
    TLabel *Label5;
    TLabel *Label1;
    TComboBox *cbModuleID;
    TComboBox *cbCom;
    TComboBox *cbBaudRate;
    TComboBox *cbChecksum;
    TEdit *eAddress;
    TEdit *eSlot;
    TButton *btnActive;
    TButton *btnExit;
    TTimer *tmLoop;
    TLabel *Label6;
    TEdit *eInVal;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall btnActiveClick(TObject *Sender);
    void __fastcall tmLoopTimer(TObject *Sender);
    void __fastcall btnExitClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
