//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "i7000.h"
#include "I7000u.cpp"
#include "i8000.h"
#include "i87000.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"


TForm1 *Form1;

WORD  wRtn;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
     // Initialize Setting for GUI
     cbModuleID->ItemIndex = 0;
     cbCom->ItemIndex      = 0;
     cbBaudRate->ItemIndex = 4;
     cbChecksum->ItemIndex = 0;

     // Setting the COM port strings
     ISetCOMString( cbCom, 1, 255 );
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnActiveClick(TObject *Sender)
{
     // Stop by user
     if ( btnActive->Caption == "Stop")
     {
          tmLoop->Enabled = false; // Stop Timer
          Sleep(500);              // Wait the tmLoop to end
          Close_Com( gcPort );     // Close COM port
          btnActive->Caption = "Active";
          btnExit->Enabled   = true;
          gbConfig->Enabled  = true;
          return;
     }

     gcPort      = (char)(cbCom->ItemIndex + 1 ); // Com Port
     gdwBaudRate = StrToInt( cbBaudRate->Text );  // Baud Rate
     wRtn = IOpenCom(gcPort, gdwBaudRate);        // Open COM port
     if (wRtn != NoError)
     {
          ShowMessage( "COM port open error!!" );
          return;
     }

     gdwBuf[0] = gcPort;                           // COM Port
     gdwBuf[1] = StrToInt("0x" + eAddress->Text);  // Module Address
     gdwBuf[2] = StrToInt("0x" + cbModuleID->Text);// Module ID
     gdwBuf[3] = cbChecksum->ItemIndex;            // CheckSum Disable or Enable
     gdwBuf[4] = 100;                              // TimeOut = 0.1 second
     //gdwBuf[5] = StrToInt( "0x" + eOutVal->Text ); // 16-bit digital data to output
     gdwBuf[6] = 1;                                // string debug
     gdwBuf[7] = StrToInt( eSlot->Text );          // Slot Number for 8K series

     btnActive->Caption = "Stop";
     btnExit->Enabled   = false;
     gbConfig->Enabled  = false;
     tmLoop->Enabled    = true;    // Start Timer

}
//---------------------------------------------------------------------------

void __fastcall TForm1::tmLoopTimer(TObject *Sender)
{
     gdwBuf[5] = 0;
     // Calling the Digital Input function for 8K series
     wRtn = DigitalIn_8K(gdwBuf, gfBuf, gszSend, gszReceive);
     if (wRtn != 0)
     {
          Beep();
          eInVal->Text = "Error";
     }
     else
          eInVal->Text = IntToHex( gdwBuf[5], 4 );

}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnExitClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------

