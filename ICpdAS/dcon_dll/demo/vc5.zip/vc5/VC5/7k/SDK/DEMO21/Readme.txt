The key points of the DEMO21.EXE are given as following:
1. copy UART.DLL & I7000.DLL to c:\windows\system\*.* first
2. checksum disable
3. I7000_AnalogIn demo (for I-7017 & I-7018)
4. I7000_AnalogIn performance evalution
