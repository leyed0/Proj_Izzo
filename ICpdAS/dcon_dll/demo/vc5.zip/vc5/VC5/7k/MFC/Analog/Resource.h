//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AnalogIn.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ANALOGTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_MODULETYPE                  1000
#define IDC_COMPORT                     1001
#define IDC_BAUDRATE                    1002
#define IDC_MODULEADDRESS               1005
#define IDC_OPENFIRSTLY                 1006
#define IDC_ANALOGINPUT                 1007
#define IDC_ANALOGINPUTVALUE            1008
#define IDC_CHECKSUM                    1009
#define ID_ANALOGIN                     32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
