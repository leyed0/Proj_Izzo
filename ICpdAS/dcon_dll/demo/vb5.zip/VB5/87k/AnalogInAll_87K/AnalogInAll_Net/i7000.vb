Option Strict Off
Option Explicit On
Module i7000
	'------------------------ Error Message ------------------
	Public Const NoError As Short = 0
	Public Const FunctionError As Short = 1
	Public Const PortError As Short = 2
	Public Const BaudRateError As Short = 3
	Public Const DataError As Short = 4
	Public Const StopError As Short = 5
	Public Const ParityError As Short = 6
	Public Const CheckSumError As Short = 7
	Public Const ComPortNotOpen As Short = 8
	Public Const SendThreadCreateError As Short = 9
	Public Const SendCmdError As Short = 10
	Public Const ReadComStatusError As Short = 11
	Public Const ResultStrCheckError As Short = 12
	Public Const CmdError As Short = 13
	Public Const TimeOut As Short = 15
	Public Const ModuleIdError As Short = 17
	Public Const AdChannelError As Short = 18
	Public Const UnderInputRange As Short = 19
	Public Const ExceedInputRange As Short = 20
	Public Const InvalidateCounterNo As Short = 21
	Public Const InvalidateCounterValue As Short = 22
	
	'----------------------  UART.DLL -----------------------------------------------
	Declare Function Get_Uart_Version Lib "uart.dll" () As Short
	
	Declare Function Open_Com Lib "uart.dll" (ByVal port As Short, ByVal BaudRate As Integer, ByVal cData As Byte, ByVal cParity As Byte, ByVal cStop As Byte) As Short
	
	Declare Function Change_Baudrate Lib "uart.dll" (ByVal port As Short, ByVal lBaudrate As Integer) As Short
	
	Declare Function Change_Config Lib "uart.dll" (ByVal port As Short, ByVal BaudRate As Integer, ByVal cData As Byte, ByVal cParity As Byte, ByVal cStop As Byte) As Short
	
	Declare Function Get_Com_Status Lib "uart.dll" (ByVal port As Short) As Short
	
	Declare Function Close_Com Lib "uart.dll" (ByVal port As Short) As Boolean
	
	Declare Function Send_Binary Lib "uart.dll" (ByVal port As Short, ByRef szBuf As Byte, ByVal length As Short) As Short
	
	Declare Function Receive_Binary Lib "uart.dll" (ByVal port As Short, ByRef szResult As Byte, ByVal TimeOut As Short, ByVal length As Short, ByRef wT As Short) As Short
	
	'Receive_Binary(unsigned char cPort, char szResult[], WORD wTimeOut, WORD wLen, WORD *wT)
	
	Declare Function Send_Cmd Lib "uart.dll" (ByVal port As Short, ByVal Cmd As String, ByVal wChkSum As Short) As Short
	
	Declare Function Receive_Cmd Lib "uart.dll" (ByVal port As Short, ByVal szResult As String, ByVal TimeOut As Short, ByVal Checksum As Short, ByRef wT As Short) As Short
	
	
	Declare Function Send_Receive_Cmd Lib "uart.dll" (ByVal port As Short, ByVal szCmd As String, ByVal szResult As String, ByVal TimeOut As Short, ByVal Checksum As Short, ByRef wT As Short) As Short
	
	Declare Function Send_Receive_Binary Lib "uart.dll" (ByVal port As Short, ByRef CmdByte As Byte, ByVal in_Len As Short, ByRef ResultByte As Byte, ByVal out_Len As Short, ByVal wTimeOut As Short) As Short
	
	Declare Function ModbusGetCRC16 Lib "uart.dll" (ByRef puchMsg As Byte, ByRef crc As Byte, ByVal DataLen As Short) As Short
	
	'----------------------  I7000.DLL --------------------------------------------
	Declare Function Get_Dll_Version Lib "I7000.dll" () As Short
	Declare Function GetChCount_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByRef wDICh As Short, ByRef wDOCh As Short, ByRef wAICh As Short, ByRef wAOCh As Short) As Short
	Declare Function DigitalOutAll_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wGroupCount As Short, ByRef wDO As Integer) As Short
	Declare Function DigitalOutGroup_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wGroupIndex As Short, ByVal wDO As Integer) As Short
	Declare Function DigitalOutBit_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wBitIndex As Short, ByVal wDO As Short) As Short
	Declare Function DigitalIOReadBackAll_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByRef wDO As Integer, ByRef wDI As Integer) As Short
	Declare Function DigitalIOReadBackGroup_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wType As Short, ByVal wGroupIndex As Short, ByRef wIOValue As Integer) As Short
	Declare Function DigitalIOReadBackBit_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wType As Short, ByVal wBitIndex As Short, ByRef wIOBit As Short) As Short
	Declare Function DigitalOnLineStatus_FR Lib "I7000.dll" (ByVal bPort As Byte, ByVal bAdd As Byte, ByVal bcheck As Byte, ByVal wTimeOut As Short, ByVal wType As Short, ByRef wDIOStatus As Short) As Short
	
	Declare Function ReadConfigStatus Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function Test Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogIn Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInFsr Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInHex Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogIn8 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInAll Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function In8_7017 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function AnalogOut Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function AnalogOutReadBack Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalOut Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalOut_7016 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalOutReadBack Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalIn Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DigitalInCounterRead Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearDigitalInCounter Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DigitalInLatch Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearDigitalInLatch Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function ThermocoupleOpen_7011 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function EnableAlarm Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableAlarm Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearLatchAlarm Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmLimitValue Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadAlarmLimitValue Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadOutputAlarmState Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadEventCounter Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function ClearEventCounter Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function SetLedDisplay_7033 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function GetLedDisplay_7033 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function SetLedDisplay Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function GetLedDisplay Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function SetupLinearMapping Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableLinearMapping Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function EnableLinearMapping Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadLinearMappingStatus Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadSourceValueOfLM Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadTargetValueOfLM Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function CounterIn_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadCounterMaxValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetCounterMaxValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal MaxValue As Double) As Short
	Declare Function ReadAlarmLimitValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmLimitValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal AlarmValue As Double) As Short
	Declare Function ReadCounterStatus_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearCounter_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadOutputAlarmState_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function EnableCounterAlarm_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableCounterAlarm_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function EnableCounterAlarm_7080D Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableCounterAlarm_7080D Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetInputSignalMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadInputSignalMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadPresetCounterValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function PresetCounterValue_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal PresetValue As Double) As Short
	Declare Function StartCounting_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadModuleMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetModuleMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadLevelVolt_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadMinSignalWidth_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetMinSignalWidth_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal MinWidth As Integer) As Short
	Declare Function SetGateMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadGateMode_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DataToLED_7080 Lib "I7000.dll" (ByRef w7000 As Short, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	
	'----------------------for7082, 87082, 8080----------------------------------------------------------
	Declare Function ReadCounter Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function ReadUpDownDirPulse Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef IBuf As Short, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function ReadCounter_All Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadFreq Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadFreq_All Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function ClearCounter Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal MaxValue As Double) As Short
	Declare Function SetCounterStatus Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadCounterStatus Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String, ByVal AlarmValue As Double) As Short
	
	'--------------------- for 8K series -------------------------------------------
	Declare Function AnalogIn_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInFsr_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInHex_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInAll_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmConnect_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmLimitValue_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadAlarmLimitValue_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearLatchAlarm_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadAlarmMode_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmMode_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogOut_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogOutReadBack_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadAlarmStatus_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetConfigurationStatus_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadConfigurationStatus_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetStartUpValue_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadStartUpValue_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalOut_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalOutReadBack_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalIn_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalBitOut_8K Lib "I7000.dll" (ByRef w7000 As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalInCounterRead_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function ClearDigitalInCounter_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalInLatch_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function ClearDigitalInLatch_8K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	
	
	
	'--------------------- for 87K series -------------------------------------------
	Declare Function AnalogIn_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInFsr_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInHex_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogInAll_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function AnalogOut_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogOutReadBack_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function AnalogOutFsr_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogOutReadBackFsr_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function AnalogOutHex_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function AnalogOutReadBackHex_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function SetConfigurationStatus_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadConfigurationStatus_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetStartUpValue_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadStartUpValue_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function DigitalInCounterRead_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function ClearDigitalInCounter_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalInLatch_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function ClearDigitalInLatch_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalOut_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalOutReadBack_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalIn_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef fBuf As Single, ByVal SendTo8000 As String, ByVal ReceiveFrom8000 As String) As Short
	Declare Function DigitalBitOut_87K Lib "I7000.dll" (ByRef w7000 As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadOutputAlarmState_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function SetAlarmLimitValue_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadAlarmLimitValue_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadEventCounter_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearEventCounter_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function EnableAlarm_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableAlarm_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ClearLatchAlarm_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	Declare Function SetupLinearMapping_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DisableLinearMapping_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function EnableLinearMapping_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadLinearMappingStatus_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadSourceValueOfLM_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function ReadTargetValueOfLM_87K Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	Declare Function DigitalOut_87016 Lib "I7000.dll" (ByRef dwBuf As Integer, ByRef f7000 As Single, ByVal SendTo7000 As String, ByVal ReceiveFrom7000 As String) As Short
	
	
	'UPGRADE_NOTE: fv �ɯŬ� fv_Renamed�C ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1061"'
	Declare Function FloatToHex Lib "I7000.dll" (ByVal fv_Renamed As Single) As Integer
End Module