Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class Form1
	Inherits System.Windows.Forms.Form
#Region "Windows Form �]�p�u�㲣�ͪ��{���X "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'�N�Ұʪ���Ө��A�إߪ��Ĥ@�Ӱ������N�O�w�]���������C
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'���� Windows Form �]�p�u��һݪ��I�s�C
		InitializeComponent()
	End Sub
	'Form �мg Dispose �H�M������M��C
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'�� Windows Form �]�p�u�㪺���n��
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cboFormat As System.Windows.Forms.ComboBox
	Public WithEvents txtID As System.Windows.Forms.TextBox
	Public WithEvents txtAddr As System.Windows.Forms.TextBox
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents cmdOpenCom As System.Windows.Forms.Button
	Public WithEvents _txtAI_7 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_6 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_5 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_4 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_3 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_2 As System.Windows.Forms.TextBox
	Public WithEvents _txtAI_1 As System.Windows.Forms.TextBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdGetAnalog As System.Windows.Forms.Button
	Public WithEvents txtPort As System.Windows.Forms.TextBox
	Public WithEvents _optCheck_1 As System.Windows.Forms.RadioButton
	Public WithEvents _optCheck_0 As System.Windows.Forms.RadioButton
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents cboBaud As System.Windows.Forms.ComboBox
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents _txtAI_0 As System.Windows.Forms.TextBox
	Public WithEvents exitCmd As System.Windows.Forms.Button
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents optCheck As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents txtAI As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	'�`�N: �H�U�� Windows Form �]�p�u��һݪ��{��
	'�i�H�ϥ� Windows Form �]�p�u��i��ק�C
	'�Ф��n�ϥε{���X�s�边�i��ק�C
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.Frame2 = New System.Windows.Forms.GroupBox
		Me.cboFormat = New System.Windows.Forms.ComboBox
		Me.txtID = New System.Windows.Forms.TextBox
		Me.txtAddr = New System.Windows.Forms.TextBox
		Me.Label14 = New System.Windows.Forms.Label
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.cmdOpenCom = New System.Windows.Forms.Button
		Me._txtAI_7 = New System.Windows.Forms.TextBox
		Me._txtAI_6 = New System.Windows.Forms.TextBox
		Me._txtAI_5 = New System.Windows.Forms.TextBox
		Me._txtAI_4 = New System.Windows.Forms.TextBox
		Me._txtAI_3 = New System.Windows.Forms.TextBox
		Me._txtAI_2 = New System.Windows.Forms.TextBox
		Me._txtAI_1 = New System.Windows.Forms.TextBox
		Me.cmdClose = New System.Windows.Forms.Button
		Me.cmdGetAnalog = New System.Windows.Forms.Button
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me.txtPort = New System.Windows.Forms.TextBox
		Me.Frame3 = New System.Windows.Forms.GroupBox
		Me._optCheck_1 = New System.Windows.Forms.RadioButton
		Me._optCheck_0 = New System.Windows.Forms.RadioButton
		Me.cboBaud = New System.Windows.Forms.ComboBox
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me._txtAI_0 = New System.Windows.Forms.TextBox
		Me.exitCmd = New System.Windows.Forms.Button
		Me.Label13 = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Label10 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.optCheck = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.txtAI = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
		CType(Me.optCheck, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.txtAI, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.Text = "Demo : AnalogInAll"
		Me.ClientSize = New System.Drawing.Size(586, 354)
		Me.Location = New System.Drawing.Point(70, 145)
		Me.AutoScaleBaseSize = New System.Drawing.Size(0, 0)
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "Form1"
		Me.Frame2.Text = "Module Information"
		Me.Frame2.Size = New System.Drawing.Size(337, 78)
		Me.Frame2.Location = New System.Drawing.Point(15, 268)
		Me.Frame2.TabIndex = 29
		Me.Frame2.BackColor = System.Drawing.SystemColors.Control
		Me.Frame2.Enabled = True
		Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame2.Visible = True
		Me.Frame2.Name = "Frame2"
		Me.cboFormat.Size = New System.Drawing.Size(113, 24)
		Me.cboFormat.Location = New System.Drawing.Point(192, 45)
		Me.cboFormat.Items.AddRange(New Object(){"Engineering", "FSR %", "2's Complement", "Ohm"})
		Me.cboFormat.TabIndex = 34
		Me.cboFormat.Text = "Engineering"
		Me.cboFormat.BackColor = System.Drawing.SystemColors.Window
		Me.cboFormat.CausesValidation = True
		Me.cboFormat.Enabled = True
		Me.cboFormat.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboFormat.IntegralHeight = True
		Me.cboFormat.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboFormat.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboFormat.Sorted = False
		Me.cboFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboFormat.TabStop = True
		Me.cboFormat.Visible = True
		Me.cboFormat.Name = "cboFormat"
		Me.txtID.AutoSize = False
		Me.txtID.Size = New System.Drawing.Size(59, 22)
		Me.txtID.Location = New System.Drawing.Point(13, 44)
		Me.txtID.TabIndex = 32
		Me.txtID.Text = "87013"
		Me.txtID.AcceptsReturn = True
		Me.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtID.BackColor = System.Drawing.SystemColors.Window
		Me.txtID.CausesValidation = True
		Me.txtID.Enabled = True
		Me.txtID.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtID.HideSelection = True
		Me.txtID.ReadOnly = False
		Me.txtID.Maxlength = 0
		Me.txtID.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtID.MultiLine = False
		Me.txtID.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtID.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtID.TabStop = True
		Me.txtID.Visible = True
		Me.txtID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtID.Name = "txtID"
		Me.txtAddr.AutoSize = False
		Me.txtAddr.Size = New System.Drawing.Size(80, 24)
		Me.txtAddr.Location = New System.Drawing.Point(86, 45)
		Me.txtAddr.TabIndex = 30
		Me.txtAddr.Text = "2"
		Me.txtAddr.AcceptsReturn = True
		Me.txtAddr.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtAddr.BackColor = System.Drawing.SystemColors.Window
		Me.txtAddr.CausesValidation = True
		Me.txtAddr.Enabled = True
		Me.txtAddr.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtAddr.HideSelection = True
		Me.txtAddr.ReadOnly = False
		Me.txtAddr.Maxlength = 0
		Me.txtAddr.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtAddr.MultiLine = False
		Me.txtAddr.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtAddr.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtAddr.TabStop = True
		Me.txtAddr.Visible = True
		Me.txtAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtAddr.Name = "txtAddr"
		Me.Label14.Text = "Data Format"
		Me.Label14.Size = New System.Drawing.Size(95, 20)
		Me.Label14.Location = New System.Drawing.Point(195, 22)
		Me.Label14.TabIndex = 35
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label14.BackColor = System.Drawing.SystemColors.Control
		Me.Label14.Enabled = True
		Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label14.UseMnemonic = True
		Me.Label14.Visible = True
		Me.Label14.AutoSize = False
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label14.Name = "Label14"
		Me.Label9.Text = "ID:"
		Me.Label9.Size = New System.Drawing.Size(23, 17)
		Me.Label9.Location = New System.Drawing.Point(26, 22)
		Me.Label9.TabIndex = 33
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label9.BackColor = System.Drawing.SystemColors.Control
		Me.Label9.Enabled = True
		Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Label6.Text = "Address[Hex]:"
		Me.Label6.Size = New System.Drawing.Size(86, 17)
		Me.Label6.Location = New System.Drawing.Point(83, 23)
		Me.Label6.TabIndex = 31
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label6.BackColor = System.Drawing.SystemColors.Control
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.cmdOpenCom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdOpenCom.BackColor = System.Drawing.SystemColors.Control
		Me.cmdOpenCom.Text = "Open COM First"
		Me.cmdOpenCom.Size = New System.Drawing.Size(147, 32)
		Me.cmdOpenCom.Location = New System.Drawing.Point(400, 173)
		Me.cmdOpenCom.TabIndex = 28
		Me.cmdOpenCom.CausesValidation = True
		Me.cmdOpenCom.Enabled = True
		Me.cmdOpenCom.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdOpenCom.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdOpenCom.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdOpenCom.TabStop = True
		Me.cmdOpenCom.Name = "cmdOpenCom"
		Me._txtAI_7.AutoSize = False
		Me._txtAI_7.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_7.Location = New System.Drawing.Point(457, 130)
		Me._txtAI_7.TabIndex = 27
		Me._txtAI_7.AcceptsReturn = True
		Me._txtAI_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_7.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_7.CausesValidation = True
		Me._txtAI_7.Enabled = True
		Me._txtAI_7.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_7.HideSelection = True
		Me._txtAI_7.ReadOnly = False
		Me._txtAI_7.Maxlength = 0
		Me._txtAI_7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_7.MultiLine = False
		Me._txtAI_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_7.TabStop = True
		Me._txtAI_7.Visible = True
		Me._txtAI_7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_7.Name = "_txtAI_7"
		Me._txtAI_6.AutoSize = False
		Me._txtAI_6.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_6.Location = New System.Drawing.Point(456, 93)
		Me._txtAI_6.TabIndex = 26
		Me._txtAI_6.AcceptsReturn = True
		Me._txtAI_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_6.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_6.CausesValidation = True
		Me._txtAI_6.Enabled = True
		Me._txtAI_6.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_6.HideSelection = True
		Me._txtAI_6.ReadOnly = False
		Me._txtAI_6.Maxlength = 0
		Me._txtAI_6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_6.MultiLine = False
		Me._txtAI_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_6.TabStop = True
		Me._txtAI_6.Visible = True
		Me._txtAI_6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_6.Name = "_txtAI_6"
		Me._txtAI_5.AutoSize = False
		Me._txtAI_5.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_5.Location = New System.Drawing.Point(457, 52)
		Me._txtAI_5.TabIndex = 25
		Me._txtAI_5.AcceptsReturn = True
		Me._txtAI_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_5.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_5.CausesValidation = True
		Me._txtAI_5.Enabled = True
		Me._txtAI_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_5.HideSelection = True
		Me._txtAI_5.ReadOnly = False
		Me._txtAI_5.Maxlength = 0
		Me._txtAI_5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_5.MultiLine = False
		Me._txtAI_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_5.TabStop = True
		Me._txtAI_5.Visible = True
		Me._txtAI_5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_5.Name = "_txtAI_5"
		Me._txtAI_4.AutoSize = False
		Me._txtAI_4.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_4.Location = New System.Drawing.Point(456, 13)
		Me._txtAI_4.TabIndex = 24
		Me._txtAI_4.AcceptsReturn = True
		Me._txtAI_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_4.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_4.CausesValidation = True
		Me._txtAI_4.Enabled = True
		Me._txtAI_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_4.HideSelection = True
		Me._txtAI_4.ReadOnly = False
		Me._txtAI_4.Maxlength = 0
		Me._txtAI_4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_4.MultiLine = False
		Me._txtAI_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_4.TabStop = True
		Me._txtAI_4.Visible = True
		Me._txtAI_4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_4.Name = "_txtAI_4"
		Me._txtAI_3.AutoSize = False
		Me._txtAI_3.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_3.Location = New System.Drawing.Point(169, 131)
		Me._txtAI_3.TabIndex = 23
		Me._txtAI_3.AcceptsReturn = True
		Me._txtAI_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_3.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_3.CausesValidation = True
		Me._txtAI_3.Enabled = True
		Me._txtAI_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_3.HideSelection = True
		Me._txtAI_3.ReadOnly = False
		Me._txtAI_3.Maxlength = 0
		Me._txtAI_3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_3.MultiLine = False
		Me._txtAI_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_3.TabStop = True
		Me._txtAI_3.Visible = True
		Me._txtAI_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_3.Name = "_txtAI_3"
		Me._txtAI_2.AutoSize = False
		Me._txtAI_2.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_2.Location = New System.Drawing.Point(168, 93)
		Me._txtAI_2.TabIndex = 22
		Me._txtAI_2.AcceptsReturn = True
		Me._txtAI_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_2.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_2.CausesValidation = True
		Me._txtAI_2.Enabled = True
		Me._txtAI_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_2.HideSelection = True
		Me._txtAI_2.ReadOnly = False
		Me._txtAI_2.Maxlength = 0
		Me._txtAI_2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_2.MultiLine = False
		Me._txtAI_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_2.TabStop = True
		Me._txtAI_2.Visible = True
		Me._txtAI_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_2.Name = "_txtAI_2"
		Me._txtAI_1.AutoSize = False
		Me._txtAI_1.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_1.Location = New System.Drawing.Point(169, 52)
		Me._txtAI_1.TabIndex = 21
		Me._txtAI_1.AcceptsReturn = True
		Me._txtAI_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_1.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_1.CausesValidation = True
		Me._txtAI_1.Enabled = True
		Me._txtAI_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_1.HideSelection = True
		Me._txtAI_1.ReadOnly = False
		Me._txtAI_1.Maxlength = 0
		Me._txtAI_1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_1.MultiLine = False
		Me._txtAI_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_1.TabStop = True
		Me._txtAI_1.Visible = True
		Me._txtAI_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_1.Name = "_txtAI_1"
		Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
		Me.cmdClose.Text = "Close COM"
		Me.cmdClose.Size = New System.Drawing.Size(147, 32)
		Me.cmdClose.Location = New System.Drawing.Point(402, 266)
		Me.cmdClose.TabIndex = 20
		Me.cmdClose.CausesValidation = True
		Me.cmdClose.Enabled = True
		Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdClose.TabStop = True
		Me.cmdClose.Name = "cmdClose"
		Me.cmdGetAnalog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdGetAnalog.BackColor = System.Drawing.SystemColors.Control
		Me.cmdGetAnalog.Text = "Get Analog"
		Me.cmdGetAnalog.Size = New System.Drawing.Size(147, 32)
		Me.cmdGetAnalog.Location = New System.Drawing.Point(401, 220)
		Me.cmdGetAnalog.TabIndex = 18
		Me.cmdGetAnalog.CausesValidation = True
		Me.cmdGetAnalog.Enabled = True
		Me.cmdGetAnalog.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdGetAnalog.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdGetAnalog.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdGetAnalog.TabStop = True
		Me.cmdGetAnalog.Name = "cmdGetAnalog"
		Me.Frame1.Text = "Configuration the COM Port Setting"
		Me.Frame1.Size = New System.Drawing.Size(337, 95)
		Me.Frame1.Location = New System.Drawing.Point(14, 170)
		Me.Frame1.TabIndex = 3
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Name = "Frame1"
		Me.txtPort.AutoSize = False
		Me.txtPort.Size = New System.Drawing.Size(58, 20)
		Me.txtPort.Location = New System.Drawing.Point(90, 18)
		Me.txtPort.TabIndex = 19
		Me.txtPort.Text = "1"
		Me.txtPort.AcceptsReturn = True
		Me.txtPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPort.BackColor = System.Drawing.SystemColors.Window
		Me.txtPort.CausesValidation = True
		Me.txtPort.Enabled = True
		Me.txtPort.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPort.HideSelection = True
		Me.txtPort.ReadOnly = False
		Me.txtPort.Maxlength = 0
		Me.txtPort.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPort.MultiLine = False
		Me.txtPort.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPort.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPort.TabStop = True
		Me.txtPort.Visible = True
		Me.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPort.Name = "txtPort"
		Me.Frame3.Text = "CheckSum"
		Me.Frame3.Size = New System.Drawing.Size(312, 40)
		Me.Frame3.Location = New System.Drawing.Point(13, 47)
		Me.Frame3.TabIndex = 8
		Me.Frame3.BackColor = System.Drawing.SystemColors.Control
		Me.Frame3.Enabled = True
		Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame3.Visible = True
		Me.Frame3.Name = "Frame3"
		Me._optCheck_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optCheck_1.Text = "Enable"
		Me._optCheck_1.Size = New System.Drawing.Size(64, 25)
		Me._optCheck_1.Location = New System.Drawing.Point(177, 11)
		Me._optCheck_1.TabIndex = 10
		Me._optCheck_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optCheck_1.BackColor = System.Drawing.SystemColors.Control
		Me._optCheck_1.CausesValidation = True
		Me._optCheck_1.Enabled = True
		Me._optCheck_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optCheck_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._optCheck_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optCheck_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optCheck_1.TabStop = True
		Me._optCheck_1.Checked = False
		Me._optCheck_1.Visible = True
		Me._optCheck_1.Name = "_optCheck_1"
		Me._optCheck_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optCheck_0.Text = "Disable"
		Me._optCheck_0.Size = New System.Drawing.Size(71, 25)
		Me._optCheck_0.Location = New System.Drawing.Point(77, 11)
		Me._optCheck_0.TabIndex = 9
		Me._optCheck_0.Checked = True
		Me._optCheck_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optCheck_0.BackColor = System.Drawing.SystemColors.Control
		Me._optCheck_0.CausesValidation = True
		Me._optCheck_0.Enabled = True
		Me._optCheck_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optCheck_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._optCheck_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optCheck_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optCheck_0.TabStop = True
		Me._optCheck_0.Visible = True
		Me._optCheck_0.Name = "_optCheck_0"
		Me.cboBaud.Size = New System.Drawing.Size(89, 24)
		Me.cboBaud.Location = New System.Drawing.Point(242, 19)
		Me.cboBaud.Items.AddRange(New Object(){"115200", "57600", "38400", "19200", "9600", "4800", "2400", "1200"})
		Me.cboBaud.TabIndex = 4
		Me.cboBaud.Text = "9600"
		Me.cboBaud.BackColor = System.Drawing.SystemColors.Window
		Me.cboBaud.CausesValidation = True
		Me.cboBaud.Enabled = True
		Me.cboBaud.ForeColor = System.Drawing.SystemColors.WindowText
		Me.cboBaud.IntegralHeight = True
		Me.cboBaud.Cursor = System.Windows.Forms.Cursors.Default
		Me.cboBaud.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cboBaud.Sorted = False
		Me.cboBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown
		Me.cboBaud.TabStop = True
		Me.cboBaud.Visible = True
		Me.cboBaud.Name = "cboBaud"
		Me.Label3.Text = "COM Port:"
		Me.Label3.Size = New System.Drawing.Size(66, 19)
		Me.Label3.Location = New System.Drawing.Point(12, 19)
		Me.Label3.TabIndex = 6
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label4.Text = "Baud Rate:"
		Me.Label4.Size = New System.Drawing.Size(71, 19)
		Me.Label4.Location = New System.Drawing.Point(157, 20)
		Me.Label4.TabIndex = 5
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me._txtAI_0.AutoSize = False
		Me._txtAI_0.Size = New System.Drawing.Size(97, 25)
		Me._txtAI_0.Location = New System.Drawing.Point(168, 16)
		Me._txtAI_0.TabIndex = 1
		Me._txtAI_0.AcceptsReturn = True
		Me._txtAI_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me._txtAI_0.BackColor = System.Drawing.SystemColors.Window
		Me._txtAI_0.CausesValidation = True
		Me._txtAI_0.Enabled = True
		Me._txtAI_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._txtAI_0.HideSelection = True
		Me._txtAI_0.ReadOnly = False
		Me._txtAI_0.Maxlength = 0
		Me._txtAI_0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me._txtAI_0.MultiLine = False
		Me._txtAI_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._txtAI_0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me._txtAI_0.TabStop = True
		Me._txtAI_0.Visible = True
		Me._txtAI_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me._txtAI_0.Name = "_txtAI_0"
		Me.exitCmd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.exitCmd.BackColor = System.Drawing.SystemColors.Control
		Me.exitCmd.Text = "Exit"
		Me.exitCmd.Size = New System.Drawing.Size(147, 32)
		Me.exitCmd.Location = New System.Drawing.Point(401, 307)
		Me.exitCmd.TabIndex = 0
		Me.exitCmd.CausesValidation = True
		Me.exitCmd.Enabled = True
		Me.exitCmd.ForeColor = System.Drawing.SystemColors.ControlText
		Me.exitCmd.Cursor = System.Windows.Forms.Cursors.Default
		Me.exitCmd.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.exitCmd.TabStop = True
		Me.exitCmd.Name = "exitCmd"
		Me.Label13.Text = "The Analog Input of Ch7:"
		Me.Label13.Size = New System.Drawing.Size(145, 17)
		Me.Label13.Location = New System.Drawing.Point(304, 136)
		Me.Label13.TabIndex = 17
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label13.BackColor = System.Drawing.SystemColors.Control
		Me.Label13.Enabled = True
		Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label13.UseMnemonic = True
		Me.Label13.Visible = True
		Me.Label13.AutoSize = False
		Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label13.Name = "Label13"
		Me.Label12.Text = "The Analog Input of Ch6:"
		Me.Label12.Size = New System.Drawing.Size(145, 17)
		Me.Label12.Location = New System.Drawing.Point(304, 96)
		Me.Label12.TabIndex = 16
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label12.BackColor = System.Drawing.SystemColors.Control
		Me.Label12.Enabled = True
		Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Label11.Text = "The Analog Input of Ch5:"
		Me.Label11.Size = New System.Drawing.Size(145, 17)
		Me.Label11.Location = New System.Drawing.Point(304, 56)
		Me.Label11.TabIndex = 15
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label11.BackColor = System.Drawing.SystemColors.Control
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Label10.Text = "The Analog Input of Ch4:"
		Me.Label10.Size = New System.Drawing.Size(145, 17)
		Me.Label10.Location = New System.Drawing.Point(304, 16)
		Me.Label10.TabIndex = 14
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label10.BackColor = System.Drawing.SystemColors.Control
		Me.Label10.Enabled = True
		Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label10.UseMnemonic = True
		Me.Label10.Visible = True
		Me.Label10.AutoSize = False
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label10.Name = "Label10"
		Me.Label5.Text = "The Analog Input of Ch3:"
		Me.Label5.Size = New System.Drawing.Size(145, 17)
		Me.Label5.Location = New System.Drawing.Point(16, 136)
		Me.Label5.TabIndex = 13
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label2.Text = "The Analog Input of Ch2:"
		Me.Label2.Size = New System.Drawing.Size(145, 17)
		Me.Label2.Location = New System.Drawing.Point(16, 96)
		Me.Label2.TabIndex = 12
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label1.Text = "The Analog Input of Ch1:"
		Me.Label1.Size = New System.Drawing.Size(145, 17)
		Me.Label1.Location = New System.Drawing.Point(16, 56)
		Me.Label1.TabIndex = 11
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Label8.Text = "COM Port:"
		Me.Label8.Size = New System.Drawing.Size(89, 25)
		Me.Label8.Location = New System.Drawing.Point(48, 248)
		Me.Label8.TabIndex = 7
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label8.BackColor = System.Drawing.SystemColors.Control
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label7.Text = "The Analog Input of Ch0:"
		Me.Label7.Size = New System.Drawing.Size(145, 17)
		Me.Label7.Location = New System.Drawing.Point(16, 16)
		Me.Label7.TabIndex = 2
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label7.BackColor = System.Drawing.SystemColors.Control
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Controls.Add(Frame2)
		Me.Controls.Add(cmdOpenCom)
		Me.Controls.Add(_txtAI_7)
		Me.Controls.Add(_txtAI_6)
		Me.Controls.Add(_txtAI_5)
		Me.Controls.Add(_txtAI_4)
		Me.Controls.Add(_txtAI_3)
		Me.Controls.Add(_txtAI_2)
		Me.Controls.Add(_txtAI_1)
		Me.Controls.Add(cmdClose)
		Me.Controls.Add(cmdGetAnalog)
		Me.Controls.Add(Frame1)
		Me.Controls.Add(_txtAI_0)
		Me.Controls.Add(exitCmd)
		Me.Controls.Add(Label13)
		Me.Controls.Add(Label12)
		Me.Controls.Add(Label11)
		Me.Controls.Add(Label10)
		Me.Controls.Add(Label5)
		Me.Controls.Add(Label2)
		Me.Controls.Add(Label1)
		Me.Controls.Add(Label8)
		Me.Controls.Add(Label7)
		Me.Frame2.Controls.Add(cboFormat)
		Me.Frame2.Controls.Add(txtID)
		Me.Frame2.Controls.Add(txtAddr)
		Me.Frame2.Controls.Add(Label14)
		Me.Frame2.Controls.Add(Label9)
		Me.Frame2.Controls.Add(Label6)
		Me.Frame1.Controls.Add(txtPort)
		Me.Frame1.Controls.Add(Frame3)
		Me.Frame1.Controls.Add(cboBaud)
		Me.Frame1.Controls.Add(Label3)
		Me.Frame1.Controls.Add(Label4)
		Me.Frame3.Controls.Add(_optCheck_1)
		Me.Frame3.Controls.Add(_optCheck_0)
		Me.optCheck.SetIndex(_optCheck_1, CType(1, Short))
		Me.optCheck.SetIndex(_optCheck_0, CType(0, Short))
		Me.txtAI.SetIndex(_txtAI_7, CType(7, Short))
		Me.txtAI.SetIndex(_txtAI_6, CType(6, Short))
		Me.txtAI.SetIndex(_txtAI_5, CType(5, Short))
		Me.txtAI.SetIndex(_txtAI_4, CType(4, Short))
		Me.txtAI.SetIndex(_txtAI_3, CType(3, Short))
		Me.txtAI.SetIndex(_txtAI_2, CType(2, Short))
		Me.txtAI.SetIndex(_txtAI_1, CType(1, Short))
		Me.txtAI.SetIndex(_txtAI_0, CType(0, Short))
		CType(Me.txtAI, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.optCheck, System.ComponentModel.ISupportInitialize).EndInit()
	End Sub
#End Region 
#Region "�ɯŤ䴩 "
	Private Shared m_vb6FormDefInstance As Form1
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As Form1
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New Form1()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	'How to run this demo program  2005/05/06 by martin
	'1. Use DCON Utility to find out the following information
	'       BaudRate
	'       Checksum
	'       Data type (engineering, FSR %, 2's complement, ohm)
	'       channel count of AI module
	'2. Producure to run the run the demo
	'       configure the COM Port setting
	'       configure the module information
	'       open com port
	'       get Analong input data from module
	'       close the com port when application end
	
	
	Dim port As Short
	Dim BaudRate As Integer
	Dim sendStr As String
	Dim recStr As String
	Dim aiCh As Short
	Dim dwBuf(20) As Integer
	Dim fBuf(20) As Single
	Dim moduleId As Integer
	Dim dataType As Short
	
	' When want to get data from module, the first step is to define the COM port configuration
	' And the format of all the ICP DAS module are
	' cData:       8
	' cParity:     0 ==> Non Parity    (NonParity)
	' cStop        0 ==> 1 Stop Bit    (OneStopBit)
	' Please use DCON Utility to find out the baudrate value
	Private Sub cmdOpenCom_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOpenCom.Click
		Dim iRet As Short
		Dim iRes As Short
		Dim dataBit, parity As Object
		Dim stopBit As Short
		port = Val(txtPort.Text)
		
		'UPGRADE_WARNING: �L�k�ѪR���� dataBit ���w�]�ݩʡC ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		dataBit = 8
		'UPGRADE_WARNING: �L�k�ѪR���� parity ���w�]�ݩʡC ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		parity = 0
		stopBit = 0
		BaudRate = CInt(cboBaud.Text)
		'UPGRADE_WARNING: �L�k�ѪR���� parity ���w�]�ݩʡC ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: �L�k�ѪR���� dataBit ���w�]�ݩʡC ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		iRet = Open_Com(port, BaudRate, dataBit, parity, stopBit)
		If iRet > 0 Then
			MsgBox("Quit this demo?", MsgBoxStyle.YesNo, "OPEN_COM Error Code:" & Str(iRet))
			Exit Sub
		End If
	End Sub
	
	Private Sub exitCmd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles exitCmd.Click
		Me.Close()
	End Sub
	
	'When application exit, it must be close the com port, even the application does not open com port
	'UPGRADE_WARNING: Form �ƥ� Form1.Unload ���s�欰�C ���@�U�H���o�ԲӸ�T: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub Form1_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
		Close_Com(port)
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Close_Com(port)
	End Sub
	
	Private Sub Form1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Dim i As Short
		'When use DLL function, the parameters of sendStr and recStr
		'must define the string space for them,or the program will be end abnormally if dwBuf(6)=1
		sendStr = Space(200)
		recStr = Space(200)
		VB6.SetItemString(cboFormat, 0, "0  Engineering")
		VB6.SetItemString(cboFormat, 1, "1  FSR %")
		VB6.SetItemString(cboFormat, 2, "2  2's Complement")
		VB6.SetItemString(cboFormat, 3, "3  Ohm")
		cboFormat.SelectedIndex = 0
		
	End Sub
	
	'====== Input parameter ====================================
	' dwBuf[0]; RS-232 port number: 1 ~ 255
	' dwBuf[1]; Module address: 0x00 ~ 0xFF
	' dwBuf[2]; Module ID:
	' dwBuf[3]; Checksum: 0=disable, 1=enable
	' dwBuf[4]; TimeOut: Normal=200 (ms)
	' dwBuf[6]; Debug:   0=disable
	'                              1=enable:   copy command string (sent to module)
	'
	' dwBuf[7];              // Data Foramt, 0:Engineer 1:FSR  2:Hex 3:Ohm
	'====== Output parameter ===================================
	'
	' fBuf[0]=analog input value of channel[0]
	' fBuf[1]=analog input value of channel[1]
	'....
	'....
	'....
	' fBuf[aiCh-1]=analog input value of channel[aiCh-1]
	'
	
	Private Sub cmdGetAnalog_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGetAnalog.Click
		Dim msg As String
		Dim iRet As Short
		Dim i As Short
		
		moduleId = CInt("&H" & txtID.Text) ' Module ID
		
		dwBuf(0) = port
		dwBuf(1) = Val("&H" & txtAddr.Text) ' Module Address
		dwBuf(2) = moduleId
		If optCheck(0).Checked = True Then
			dwBuf(3) = 0 ' CheckSum Disable
		Else
			dwBuf(3) = 1
		End If
		dwBuf(4) = 1000 ' TimeOut = 1 second
		dwBuf(5) = 0 ' channel no, Don't care in this Demo
		dwBuf(6) = 1 ' string debug
		
		dataType = cboFormat.SelectedIndex
		dwBuf(7) = dataType
		
		'dataType is the dataformat of AI module
		'0 engineering
		'1 FSR %
		'2 2's complement
		'3 ohm (only RTD has this type)
		'please use DCON Utility to check the dataType of this AI module
		
		
		iRet = AnalogInAll_87K(dwBuf(0), fBuf(0), sendStr, recStr)
        If iRet = 15 Or iRet = 12 Then
            Beep()
            msg = "The Error Code:" & Str(iRet)
            MsgBox(msg, 0, "AnalogInAll() error !!!")
        Else

            'The AICh is the total channel count of AI module
            'If the moduleID is not included in this demo,
            'please add to the following Select case statement
            Select Case moduleId
                Case &H87013
                    aiCh = 4
                Case &H87017, &H87018, &H87019, &H87015
                    aiCh = 8
            End Select

            For i = 0 To aiCh - 1
                If dataType = 2 Then
                    txtAI(i).Text = VB.Right("0000" & Hex(dwBuf(8 + i)), 4)
                Else
                    txtAI(i).Text = VB6.Format(fBuf(i), "0.000")
                End If
            Next i
        End If
		
	End Sub
End Class